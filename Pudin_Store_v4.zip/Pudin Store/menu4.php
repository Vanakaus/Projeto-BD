<?php
	echo "
  <main role='main'>
      <div id='categorias'>
        <ul>
          <li><a href='chamado.php'>Abrir Chamado</a></li>
          <li><a href='chamadoh.php'>Historico</a></li>
          <li><a href='configurar.php'>Alterar Dados</a></li>
        </ul>
      </div>>";

?>