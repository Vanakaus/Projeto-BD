<?php
 require_once "config.php";


 if(isset($_FILES['arquivo'])){
  $nome = "temp.jpg";
  $dir = "Produtos/";

  move_uploaded_file($_FILES['arquivo']['tmp_name'], $dir.$nome);

if(!isset($_SESSION['id'])){
    } else {
  rename("Produtos/temp.jpg", "Produtos/".$_SESSION['id'].".jpg");
 }
}
 ?>
<!doctype html>
<html>
  <head>


    <script type="text/javascript">
      function excluir(id, nome){

        var r = confirm("Você realmente deseja excluir esse produto? \n" + nome);
        if (r == true) {
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              var x = xmlhttp.responseText; // Resposta do login

              /* Condição para reposta ao usuario ou redirecionamento da pagina */
              switch(x) {
                case "0":
                  alert("Exclusão efetuada com sucesso.");
                  location.reload(true);
                break;
                default:
                  alert("Problemas Internos, favor entrar em contato.");
              }
            }
        };
        xmlhttp.open("GET", "prodbtn.php?btn=exc&id=" + id, true);
        xmlhttp.send();
        } else {
          alert("Exclusão cancelada!");
        }
      }

      function alte(id, nome, nm, desc, val, des){

        var r = confirm("Você realmente deseja alterar esse produto? \n" + nome);
        if (r == true) {
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              var x = xmlhttp.responseText; // Resposta do login

              /* Condição para reposta ao usuario ou redirecionamento da pagina */
              switch(x) {
                case "0":
                  alert("alteração efetuada com sucesso.");
                break;
                default:
                  alert("Problemas Internos, favor entrar em contato.");
              }
            }
        };
        xmlhttp.open("GET", "prodbtn.php?btn=alt&id=" + id + "&nome=" + nm + "&desc=" + desc + "&val=" + val + "&des=" + des, true);
        xmlhttp.send();
        } else {
          alert("Exclusão cancelada!");
        }
      }

    </script>

    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu2.php";
  ?>

      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Gerenciar</p></div>

          <table>
            <tr>
              <th>
                ID
              </th>
              <th>
                Nome
              </th>
              <th clas="tami">
                Foto
              </th>
              <th>
                Descrição
              </th>
              <th>
                Valor
              </th>
              <th>
                Desconto
              </th>
              <th colspan="2">
                Opções
              </th>
            </tr>

            <?php

            $select = mysqli_query($conectbd, "select * from produto order by id");

              $x = 0;

              while ($rows = mysqli_fetch_array($select)){
                echo "
                      <form action='prodg.php' method='POST' enctype='multipart/form-data'>
                      <tr>
                      <td>
                        ".$rows['id']."
                      </td>
                      <td>
                        <textarea id='nm".$rows['id']."' class='tamn'>".$rows['nome']."</textarea>
                      </td>
                      <td>
                        <img class='card-img-top tami' src='Produtos/".$rows['id'].".jpg' alt='Card image cap'>
                        </br>
                          <input type='file' required name='arquivo'>
                      </td>
                      <td>
                        <textarea id='desc".$rows['id']."' class='tamd'>".$rows['descricao']."</textarea>
                      </td>
                      <td>
                        <textarea id='val".$rows['id']."' class='tamp'>".$rows['valor']."</textarea>
                      </td>
                      <td>
                        <textarea id='des".$rows['id']."' class='tamp'>".$rows['desconto']."</textarea>
                      </td>
                      <td>
                        <button type='button' class='tamb' Onclick='excluir(".$rows['id'].", \"".$rows['nome']."\")'>Excluir</button>
                      </td>
                      <td>
                        <input type='submit' value='Salvar' Onclick='alte(".$rows['id'].", \"".$rows['nome']."\", nm".$rows['id'].".value, desc".$rows['id'].".value, val".$rows['id'].".value, des".$rows['id'].".value)' class='tamb'>
                      </td>
                    </tr>
                    </form>
                    ";
              }
                    ?>
          </table>        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
