<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <script type="text/javascript">
      function inc(cli, mot, obs){
  
    if (cli == 0 || mot == 0){
      alert("Campos em branco, preencha-os para continuar.");
      }else{
        
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var x = xmlhttp.responseText; // Resposta da inclusão de chamado
        
        switch(x) {
        case "0":
          alert("Chamado aberto com sucesso;");
          window.location.reload();
        break;
        default:
          alert("Problemas Internos, favor contatar a World Computer.");
        
        }
      }
        };
        xmlhttp.open("GET", "botoes.php?cls=inc&id=0&cli=" + cli + "&mot=" + mot + "&obs=" + obs, true);
        xmlhttp.send();
      } 
  }
    </script>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>


    
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Suporte</p></div>

          <div id="contaba">
            <h1>Incluir Chamado</h1>
            
            </br>
            </br>

            <div id='cli'>Cliente: <select id ='cliente'  class='appearance-select'>
              <option selected hidden value='0'>Qual o cliente</option>
              <?php
              $select = mysqli_query($conectbd, "select * from cliente c, login l where c.user = l.user order by l.nome");

              while ($rows = mysqli_fetch_array($select)){
                echo "<option value='".$rows['user']."'>".$rows['nome']."</option>
                ";
              }

                ?>
            </select></br></br>
          </div>
          

          Motivo:
          </br></br>
          
          <textarea id = 'motivo' rows='8' cols='70'></textarea>
          </select>
        </br></br></br>
        <!-- Observação -->
        <div id='observacao'>
          <p> Observação: </p>
          
          <textarea id = 'obs' rows='10' cols='70'></textarea>
        </div>
        </br></br>
        <input type='button' id='btn' class='btn' value='Enviar' onclick='inc(cliente.value, motivo.value, obs.value)' />
        </div>
      </br>



        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
