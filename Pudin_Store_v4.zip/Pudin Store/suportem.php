<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <script type="text/javascript">
      function cad(user, cpf, nome, senha0, senha1){

        if (user.length == 0 || cpf.length == 0 || senha0.length == 0 || senha1.length == 0) { // Verificação se o login está em branco
          alert("Campo(s) em branco(s). Favor prenche-los.");
          return;
          } else {
            if (senha0 != senha1) {
              alert("As senhas não coincidem.");
            } else {

              var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var x = xmlhttp.responseText; // Resposta do login

                   /* Condição para reposta ao usuario ou redirecionamento da pagina */
                  switch(x) {
                  case "0":
                  alert("Cadastro efetuado com sucesso.");
                  window.location.replace("index.php");
                  break;
                  case "1":
                  alert("Usuário indisponivel.");
                  break;
                  default:
                  alert("Problemas Internos, favor entrar em contato.");
                }
             }
        };
        xmlhttp.open("GET", "logcad.php?logcad=cad2&user=" + user + "&cpf=" + cpf + "&nome=" + nome + "&senha=" + senha0, true);
        xmlhttp.send();
            }
          }
      }
    </script>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="stylel.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>


    
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Suporte</p></div>

<div id="contaba">
   <h1>Incluir funcionário</h1>
  
  </br>

<div id='cli'></br></div>


  <form method="GET" action="">
                    <table id="encad_table">
                      <tr>
                       <td>Usuário:</td>
                        <td>
                          <input type="text" name="usuario" id="usuario_cad" class="campo" maxlength="60" placeholder="Usuário" >
                        </td>
                     </tr>
                     <tr>
                       <td>Nome:</td>
                        <td>
                          <input type="text" name="nome" id="nome_cad" class="campo" maxlength="60" placeholder="Nome" >
                        </td>
                     </tr>
                     <tr>
                       <td>CPF:</td>
                        <td>
                          <input type="number" name="cpf" id="cpf_cad" class="campo" maxlength="40" placeholder="CPF" >
                        </td>
                     </tr>
                      <tr>
                        <td>Senha:</td>
                       <td>
                          <input type="password" name="senha" id="senha0_cad" class="campo" maxlength="22" placeholder="Senha" >
                        </td>
                     </tr>
                      <tr>
                        <td>Comfirmar</br>Senha:</td>
                       <td>
                          <input type="password" name="senha" id="senha1_cad" class="campo" maxlength="22" placeholder="Comfirmar Senha" >
                        </td>
                     </tr>
                     <tr id="btns">
                        <td colspan="2">
                         <!-- Botão 1 -->
                          <button type="button" id="btn_cad" class="btn" Onclick="cad(usuario_cad.value, cpf_cad.value, nome_cad.value, senha0_cad.value, senha1_cad.value)"  class="area_btn">
                            <div class="efeito_btn"></div><div class="efeito_txt" id="text_cad">Cadastrar</div>
                          </button>
                       </td>
                     </tr>
                    </table>
                   </form>
  
  
  </br>
  </br>
   </div>


        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
