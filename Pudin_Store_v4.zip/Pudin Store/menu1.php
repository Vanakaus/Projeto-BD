  <!DOCTYPE html>
  <html>
  <head>
    <script type="text/javascript">
      function cat(cat, nmc){
        var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var x = xmlhttp.responseText; // Resposta do login
                }

        };
        xmlhttp.open("GET", "cat.php?cat=" + cat + "&nmc=" + nmc, true);
        xmlhttp.send();
        location.reload();
      }
    </script>
  </head>
  <body>
  
  </body>
  </html>


<?php
  $select = mysqli_query($conectbd, "select * from categoria order by id;");
	echo "
    <main role='main'>

      <div id='categorias'>
      	<ul>";

  while ($row = mysqli_fetch_array($select)){

    echo "<li><a href='javascript:cat(".$row['id'].", \"".$row['nome']."\");'>".$row['nome']."</a></li>";
  }

  echo "</ul>
      </div>";

?>