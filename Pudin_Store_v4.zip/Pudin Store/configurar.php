<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>


<script>
  function alterar(senhaa, senhan, senhac){
    if (senhan == "" || senhac == "" || senhaa == "") {
    alert("Um ou mais campos estão em branco. Preencha-os para alterar sua senha.");
  } else{
    if (senhac == senhan) {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
    
    if(this.responseText == "1")
    {
      alert("Senha alterada com sucesso.");
      window.location.reload();
    } else{
      if(this.responseText == "2")
      {
        alert("Senha atual errada. Tente novamente.");
        window.location.reload();
      } else{
        alert("Erro interno, Favor entrar em contato.");
      }
    }
            }
        };
    
    xmlhttp.open('GET', 'btn_cli.php?btn=alt&senhaa=' + senhaa + '&senhan=' + senhan, true);
        xmlhttp.send(); 
    } else {
      alert("Senhas novas não coincidem.");
  }
}
}
</script>

    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu4.php";
  ?>

      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Chamado</p></div>

          <div id="alterar">
<h1>Alterar Senha</h1>
<p>Para alterar sua senha digite a senha atual, digite a senha nova, e reescreva a senha nova para confirmar e aperte em alterar.
</p>
<br>
Digite sua senha atual: &nbsp&nbsp&nbsp&nbsp
<input type="password" name="senha" id="senhaa"  maxlength="12" placeholder="Senha atual" >
<br>
<br>
<br>
Digite a senha nova: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  
<input type="password" name="senha" id="senhan"  maxlength="12" placeholder="Senha nova">
<br>
<br>
Repita a senha nova: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="password" name="senha" id="senhac"  maxlength="12" placeholder="confirmar Senha nova">
<br>
<div id="res" style="font:14px arial; margin:0px 225px; visibility:hidden;">olá</div>
<br><br><br>
<input type='button' id='btn' class='btn' value='Alterar' Onclick="alterar(senhaa.value, senhan.value, senhac.value)">


        </div>

        

      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
