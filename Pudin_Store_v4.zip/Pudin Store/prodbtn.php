<?php
	/* Início de sessão */
	
header("Content-type: text/html; charset=utf-8");
	require_once "config.php";
	
header("Content-type: text/html; charset=utf-8");
	/* Request do usuario e senha */
	$btn = $_REQUEST["btn"];

	/* coneção com o banco e a tabela. Select na tabela */
	$conectbd = mysqli_connect($_SESSION["host"], $_SESSION["user"], $_SESSION["pswd"], $_SESSION["banco"]);


	if ($btn == "exc") {
	$id = $_REQUEST["id"];
		$excluir = mysqli_query($conectbd, "delete from produto where id='$id';");
		$deletar = unlink("Produtos/".$id.".jpg");
		echo "0";
	}

	if ($btn == "alt") {
	$id = $_REQUEST["id"];
		$nome = $_REQUEST["nome"];
		$desc = $_REQUEST["desc"];
		$val = $_REQUEST["val"];
		$des = $_REQUEST["des"];

		$_SESSION['id'] = $id;

		$alterar = mysqli_query($conectbd, "update produto set nome='$nome', descricao='$desc', valor=$val, desconto=$des where id=$id;");

		if(!isset($_FILE['/Produtos/temp.jpg'])){
		} else {
			rename("/Produtos/temp.jpg", "/Produtos/".$id.".jpg");
		}

		echo "0";
	}

	if ($btn == "adc") {
		$nome = $_REQUEST["nome"];
		$desc = $_REQUEST["desc"];
		$val = $_REQUEST["val"];
		$des = $_REQUEST["des"];

		$incluir = mysqli_query($conectbd, "insert into produto (nome, descricao, valor, desconto)  values('$nome','$desc', $val, $des);");

		$select = mysqli_query($conectbd, "select id from produto order by id desc LIMIT 1;");

		$row = mysqli_fetch_array($select);

		$_SESSION['id'] = $row['id'];

		echo "0";
	}

	?>