<?php
	echo "
  <main role='main'>
      <div id='categorias'>
        <ul>
          <li><a href='suportea.php'>Em Andamento</a></li>
          <li><a href='suportef.php'>Finalizados</a></li>
          <li><a href='suportei.php'>Incluir</a></li>
          <li><a href='suportem.php'>Incluir Funcionário</a></li>
          <li><a href='configurarf.php'>Mudar Senha</a></li>
        </ul>
      </div>";

?>