<?php

session_start();


	$conectbd = mysqli_connect($_SESSION["host"], $_SESSION["user"], $_SESSION["pswd"], $_SESSION["banco"]);
	mysqli_set_charset($conectbd, 'utf8');

	$cls = $_REQUEST["cls"];
	$id = $_REQUEST["id"];
	
	/* switch para verificar qual botão foi clicado, a partir da variavel clase(tipo) - cls */
	switch($cls) {
		/* Botão atender */
    case "atd":
	
	$update = mysqli_query($conectbd, "update chamado set sts = 2, atendimento = now() where id = $id;");
        break;

		/* Botão pausar */
    case "pausar":
	$select = mysqli_query($conectbd, "select pausas from chamado where id = $id;");
	$x = mysqli_fetch_array($select);
	$pausas = ($x['pausas'] + 1);
	
	$update = mysqli_query($conectbd, "update chamado set sts = 3, pausas = $pausas where id = $id;");
	
		break;	
		/* Botão despausar */
	case "despausar":

	$update = mysqli_query($conectbd, "update chamado set sts = 2 where id = $id");
	
		break;
		/* Botão finalizado */
    case "fina":

	$servs = $_REQUEST["serv"];
	$num = strlen($servs);
	if ($num%2 == 1) {
		$num++;
	}

	$num/=2;

	for ($i=0; $i < $num; $i++) {
		$ids = substr($servs, $i*2, 1);
		$insert = mysqli_query($conectbd, "insert into execserv (id_serv, id_cham) values ('$ids', '$id');");
	}
    $update = mysqli_query($conectbd, "update chamado set sts = 4 where id = $id;");
		
        break;
		/* Botão abrir chamado */
		case "inc":
	$cliente = $_REQUEST["cli"];
	$obs = $_REQUEST["obs"];
	$mot = $_REQUEST["mot"];

	$insert = mysqli_query($conectbd, "insert into chamado (user, abertura, problema, obsc) values ('$cliente', now(), '$mot','$obs');");
	echo "0";
		
        break;
		/* Botão observação do tecnico */
		case "obst":
	$motivo = $_REQUEST["motivo"];
	
	$update = mysqli_query($conectbd, "update chamado set obst = '$motivo' where id = $id;");
	echo "1";
		
        break;
    default:
        
}
	
	
	