<?php
	/* Início de sessão */
	
	require_once "config.php";
	
	$_SESSION["cat"] = $_REQUEST["cat"];
	$_SESSION["nmcat"] = $_REQUEST["nmc"];
	echo $_SESSION["cat"];
?>