<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <script type="text/javascript">
        function botao(cls, id){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            
        }
    };

    xmlhttp.open("GET", "botoes.php?cls=" + cls + "&id=" + id, true);
    xmlhttp.send();
    
    setTimeout(function(){window.location.reload();}, 200);
    
}

function fina(id){

    <?php

    $select = mysqli_query($conectbd, "select * from servicos");
        echo "
    var serv = prompt('Por Favor digite os serviços realizados, separados por virgulas(SEM ESPAÇOS) \\nID - Nome";
    while ($rows = mysqli_fetch_array($select)){
        echo "\\n".$rows['id']." - ".$rows['servico'];
    }
    echo "', '');";
    ?>

    if (serv != null) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            
        }
    };

    xmlhttp.open("GET", "botoes.php?cls=fina&id=" + id + "&serv=" + serv, true);
    xmlhttp.send();

    setTimeout(function(){window.location.reload();}, 200);
    }
    
}

function abrir(id) {

  popupWindow = window.open("obs.php?id=" + id, "resizable=no", "width=550, height=300, left=400, top=100 ");
  
}
    </script>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>
  
  
      <div class="album py-5 bg-light">
      <div class="container">

        <div id="cat">
        <div id="tit"><p>Suporte</p></div>
      <table id='tabela'>
    <tr> <th colspan='20'>Chamados</th> </tr>

<?php
     
     
        /* Select no banco de dados para chamados em andamento */
$select = mysqli_query($conectbd, "select * from chamado c, login l where c.sts != 4 and c.user = l.user");
 
 
        // Colunas
        echo "
        <tr>
        <th class='stss'>Status</th>
        <th class='cli'>Cliente</th>
        <th class='abert'>Abertura</th>
        <th class='mot'>Motivo</th>
        <th class='ini'>Início do atendimento</th>
        <th class='paus'>Pausas</th>
        <th class='obsc'>Observação do Cliente</th>
        <th class='acs' colspan='4'>Ações</th>
        </tr>";
        
    
    
        //Linhas
        // Variável para diferenciação de Linhas
        $x=0;
        while ($rows = mysqli_fetch_array($select)){
            
        // Condição para diferenciação de Linhas
        if(($x %2) == 0){
        echo "<tr class='dif'>";
        }
        else{
        echo "<tr>";
        }
        
        /* Condição para colorir o campo status */
        switch ($rows["sts"]){
            case "1":
                echo"<td class='sts1'>ESP</td>"; 
        break;
            case "2":
                echo"<td class='sts3'>ATD</td>"; 
        break;
            case "3":
                echo"<td class='sts7'>PSD</td>"; 
        break;
            default:
                echo"<td>".$rows['statuss']."</td>";
        }
        
        echo "
        <td>".$rows['user']."</td> 
        <td>".date('d/m/Y H:i:s', strtotime($rows['abertura']))."</td> 
        <td>".$rows['problema']."</td>";

        echo "<td>".date('d/m/Y H:i:s', strtotime($rows['abertura']))."</td>";              
        
        echo "<td>".$rows['pausas']."</td> 
        <td>".$rows['obsc']."</td>";      
        
        
        //Botões
        
        //Variáveis para 'configuração' dos botões.
        $dsb = "";
        $cnt = "";
        $cls = "";
        
        //Atender
        if ($rows['sts'] != 1)
        {$dsb = "disabled";}
        else {$dsb = "";}
        
        echo "<td><button ".$dsb." class='atd' value='".$rows['id']."' onclick='botao(this.className, this.value)'>A</button></td>";
        
        //Pausar, depausar
        if ($rows['sts'] == 1 || $rows['sts'] == 4)
        {$dsb = "disabled";
        $cnt = "P";
        $cls = "pausar";}
        else {
            if ($rows['sts'] == 3)
            {$cnt = "D";
            $dsb = "";
            $cls = "despausar";}
            else {
                $dsb = "";
                $cnt = "P";
                $cls = "pausar";
            }
        }
        
        echo "<td><button ".$dsb." class='".$cls."' value='".$rows['id']."' onclick='botao(this.className, this.value)'>".$cnt."</button></td>"; 
        
        
        //Finalizar
        if ($rows['sts'] != 2)
        {$dsb = "disabled";}
        else {$dsb = "";}
        
        echo "<td><button ".$dsb." class='fnlzd' value='".$rows['id']."' onclick='fina(this.value)'>F</button></td>"; 
        
        //Observação
        if ($rows['sts'] == 1 || $rows['sts'] == 4)
        {$dsb = "disabled";}
        else {$dsb = "";}
        
        echo "<td><button ".$dsb." class='obs' value='".$rows['id']."' onclick='abrir(this.value)'>O</button></td> 
        </tr>";
        
        $x+=1;
        }
        echo "</table>";
    
    
?>

  </table>
        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
