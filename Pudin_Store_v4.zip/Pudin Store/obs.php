<?php
session_start();
	
	$conectbd = mysqli_connect($_SESSION["host"], $_SESSION["user"], $_SESSION["pswd"], $_SESSION["banco"]);
	mysqli_set_charset($conectbd, 'utf8');
		 
$id = $_REQUEST["id"];

$select = mysqli_query($conectbd, "select id, obst from chamado where id = $id");
	$x = mysqli_fetch_array($select);
	

echo "
<html>
<head>
<meta charset='UTF-8'>
<link rel='shortcut icon' href='Imagens/pudin.png'>
<title>Observação - Chamado: $id</title>
</head>

<body>";

echo "
<script>
function botao(cont){
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			
		if (this.responseText == '1')
		{
			cloose();
		}
            }
        };
		xmlhttp.open('GET', 'botoes.php?cls=obst&motivo=' + cont + '&id=' + $id, true);
		xmlhttp.send();
				
}
function cloose() {
	close();
}



</script>";

/* Corpo do 'site' */
echo "

<textarea rows='15' cols='73' id='obs'>".$x['obst']."</textarea>
  <br><br>
  <input type='button' value='OK' id='obst' onclick='botao(obs.value)'>
  <input type='button' value='Cancelar' onclick='cloose()'>



</body>

</html>";
	
?>