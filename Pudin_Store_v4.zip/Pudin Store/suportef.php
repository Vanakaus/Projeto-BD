<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>

    
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Suporte</p></div>

          <table id='tabela'>
    <tr> <th colspan='20'>Chamados</th> </tr>

<?php
     
     
        /* Select no banco de dados para chamados em andamento */
$select = mysqli_query($conectbd, "select * from chamado c, login l where c.sts = 4 and c.user = l.user"); 
 
        // Colunas
        echo "
        <tr>
        <th class='stss'>Status</th>
        <th class='cli'>Cliente</th>
        <th class='abert'>Abertura</th>
        <th class='mot'>Motivo</th>
        <th class='ini'>Início do atendimento</th>
        <th class='paus'>Pausas</th>
        <th class='obsc'>Observação do Cliente</th>
        <th class='obsc'>Observação do Tecnico</th>
        <th class='obsc'>Serviços</th>
        </tr>";
        
    
    
        //Linhas
        // Variável para diferenciação de Linhas
        $x=0;
        while ($rows = mysqli_fetch_array($select)){
            
        // Condição para diferenciação de Linhas
        if(($x %2) == 0){
        echo "<tr class='dif'>";
        }
        else{
        echo "<tr>";
        }
        
        echo"<td class='sts2'>FZD</td>"; 
                
        echo "
        <td>".$rows['user']."</td> 
        <td>".date('d/m/Y H:i:s', strtotime($rows['abertura']))."</td> 
        <td>".$rows['problema']."</td>";

        echo "<td>".date('d/m/Y H:i:s', strtotime($rows['abertura']))."</td>";              
        
        echo "<td>".$rows['pausas']."</td> 
        <td>".$rows['obsc']."</td>      
        <td>".$rows['obst']."</td>
        <td>";

        $select2 = mysqli_query($conectbd, "select * from execserv e, servicos s where s.id = e.id_serv and e.id_cham = ".$rows['id'].""); 

        while ($rows2 = mysqli_fetch_array($select2)){
          echo $rows2['servico']."</br>";
        }  

        echo "</td>";
        
        $x+=1;
        }
        echo "</table>";
    
    
?>

  </table>

        </div>
  
  

        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
