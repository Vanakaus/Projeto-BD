<?php
 require_once "config.php";

 if(isset($_FILES['arquivo'])){
  $nome = "temp.jpg";
  $dir = "Produtos/";

  move_uploaded_file($_FILES['arquivo']['tmp_name'], $dir.$nome);

if(!isset($_SESSION['id'])){
    } else {
  rename("Produtos/temp.jpg", "Produtos/".$_SESSION['id'].".jpg");
 }
}


 ?>
<!doctype html>
<html lang="en">
  <head>

    <script type="text/javascript">

      function adc(nome, desc, val, des){

        var r = confirm("Você realmente deseja adicionar este produto? \n" + nome);
        if (r == true) {
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              var x = xmlhttp.responseText; // Resposta do login

              /* Condição para reposta ao usuario ou redirecionamento da pagina */
              switch(x) {
                case "0":
                  alert("Produto adicionado com sucesso.");
                break;
                default:
                  alert("Problemas Internos, favor entrar em contato.");
              }
            }
        };
        xmlhttp.open("GET", "prodbtn.php?btn=adc&nome=" + nome + "&desc=" + desc + "&val=" + val + "&des=" + des, true);
        xmlhttp.send();
        } else {
          alert("Ação cancelada!");
        }
      }

    </script>

    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu2.php";
  ?>


      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Adicionar</p></div>

          <div id="contaba">
            <h1>Adicionar Produto</h1>
            </br>
                <form action='proda.php' method='POST' enctype='multipart/form-data'>
            <table>
              <tr>
                <td>
                  Nome:
                </td>
                <td>
                  <input type="text" name="nome" id="nome"  placeholder="Nome" />
                </td>
              </tr>
                
              <tr>
                <td>
                  Descrição:
                </td>
                <td>
                  <input type="text" name="desc" id="desc"  placeholder="Descrição" />
                </td>
              </tr>
                
              <tr>
               <td>
                  Valor:
                </td>
               <td>
                  <input type="number" name="valor" id="valor"  placeholder="Valor" />
                </td>
              </tr>
                
              <tr>
                <td>
                  Desconto:
                </td>
                <td>
                  <input type="number" name="desct" id="desct"  placeholder="Desconto" />
                </td>
              </tr>

              <tr>
                <td>
                  Foto:
                </td>
                <td>
                  <input type='file' required name='arquivo'>
                </td>
              </tr>
            </table>

        </br></br>
        <input type='submit' value='Salvar' Onclick='adc(nome.value, desc.value, valor.value, desct.value)' class="btn">
              </form>
        </div>
      </br>



        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
