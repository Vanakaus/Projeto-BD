<?php
/* Comando para não ocorrer erro de criptografia */
header("Content-type: text/html; charset=utf-8");

 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Início</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>

  <body>

    <?php 
    	require_once "header.php";
    	require_once "menu1.php";
    ?>

      <div class="album py-5 bg-light">
        <div class="container">


        <div id="cat">
        	<div id="tit">
            <?php 
              switch ($_SESSION["cat"]) {
                case '0':
                  echo "<p>Promoção</p>";
                  $cat = "";
                  break;
                  
                case '1':
                  echo "<p>Armazenamento</p>";
                  $cat = "where categoria='armazenamento'";
                  break;

                case '2':
                  echo "<p>Cabos</p>";
                  $cat = "where categoria='cabos'";
                  break;

                case '3':
                  echo "<p>Peças</p>";
                  $cat = "where categoria='pecas'";
                  break;

                case '4':
                  echo "<p>Periféricos</p>";
                  $cat = "where categoria='perifericos'";
                  break;
                default: 
                  $cat="";
              }
            ?>
          </div>
          <div class="row">




          	<?php
          		/* Select no banco de dados para chamados em andamento */
          		$select = mysqli_query($conectbd, "select * from produto $cat order by desconto desc");

          		$x = 0;

          		while ($rows = mysqli_fetch_array($select)){
          			if ($x < 12) {
          				echo "
				            	<div class='col-md-4'>
				            		<div class='card mb-4 shadow-sm'>
				            			<h3 class='titulo'>".$rows['nome']."</h1>
				            			<img class='card-img-top' src='Produtos/".$rows['id'].".jpg' alt='Card image cap'>
				            			<div class='card-body'>
				            				<p class='card-text'>".$rows['descricao']."</p>
					           	     		<div class='d-flex justify-content-between align-items-center'>
					                			<div class='btn-group'>
					                			</div>";
					                			if ($rows['desconto'] != 0) {
					                				$valor = floatval ($rows['valor']) - floatval($rows['valor']) * floatval($rows['desconto']) / 100;
					                				echo "
					                						<medium class='text-muted'>De <strike>R$".number_format($rows['valor'], 2, ',', '.')."</strike></medium>
								                		</div>
								                		<div class='d-flex justify-content-between align-items-center'>
								                			<div class='btn-group'>
								                				<button type='button' class='btn btn-sm btn-outline-secondary'>Comprar</button>
								                			</div>
								                			<medium class='text-muted'>Por R$". number_format($valor, 2, ',', '.') ."</medium>
					                				";
					                			}else {
					                				echo "
										                		</div>
										                		<div class='d-flex justify-content-between align-items-center'>
										                			<div class='btn-group'>
										                				<button type='button' class='btn btn-sm btn-outline-secondary'>Comprar</button>
										                			</div>
										                			<medium class='text-muted'>R$".number_format($rows['valor'], 2, ',', '.')."</medium>
					                				";
					                			}
					                			echo "
					                		</div>
					                	</div>
					            	</div>
					        	</div>";
          			}


				    $x++;

				}
          	?>

          </div>
        </div>
      </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
