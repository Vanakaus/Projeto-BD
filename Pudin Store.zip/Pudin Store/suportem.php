<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>


    
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Suporte</p></div>

<div id="contaba">
   <h1>Incluir funcionário</h1>
  
  </br>

<div id='cli'></br></div>

   <!-- Botões incluir e alterar -->
  <input type="radio" name="ia2" id="inc2" value="incluir" onclick="incluir2()" checked>Incluir</input>
   <input type="radio" name="ia2" id="alt2" value="alterar" onclick="alterar2()">Alterar</input>
  </br>
  
  
  <!-- Tabela para formatação dos campos -->
  <table id="tbl_inclifun">
  
  <!-- Linha de procurar usuario para alteração -->
  <tr id="opc2" hidden>
  <td>
  Login 
  </br>
  <input type="number" id="logid"  placeholder="Login" /> 
  </td>
  
  <td>
  <button value='Procurar' onclick='procuser(logid.value)'>Procurar</button>
  </td>
  </tr>
  
  <!-- Linha de separação -->
  <tr id="opc20" hidden>
  <td colspan="2" id="proc">
  </td>
  </tr>
  
  <!-- Linha Empresa e E-mail -->
  <tr>
  <td>
  Nome do(a) funcionário/empresa: 
  </br>
  <input type="text" id="user"  placeholder="usuário" /> 
  </td>
  
  
  <td>
  E-mail: 
  </br>
  <input type="text" id="eml"  placeholder="E-mail" /> 
  </td>
  </tr>
  
  <!-- Linha de alterar conta e senha -->
  <tr id="opc3" hidden>
  <td>
 Tipo de conta: </br><select id='tpct1' class='appearance-select'>
        <option selected hidden value='0'>Tipo de conta</option>
        <option value='".$rows['idt']."'>".$rows['nome']."</option>
        <option value='".$rows['idt']."'>".$rows['nome']."</option>

      </select></br></br>


   
  </td>
  
  <td>
  <input type="checkbox" id="altsnh">Alterar Senha</input> 
  </td>
  </tr>
  
  
  <!-- Linha de Login e tipo de conta -->
  <tr id="opc1">
  <td>
  Login: 
  </br>
  <input type="number" id="log"  placeholder="CPF/CNPJ" /> 
  </td>
  <td>
  
  Tipo de conta: </br><select id ='tpct' class='appearance-select'>
        <option selected hidden value='0'>Tipo de conta</option>

<option value='".$rows['idt']."'>".$rows['nome']."</option>

<option value='".$rows['idt']."'>".$rows['nome']."</option>


</select></br></br>


  </td>
  </tr>
  
  <!-- Linha da senha -->
  <tr>
  <td>
  Senha: 
  </br>
  <input type="password" id="snh"  placeholder="Senha" onkeyup="verifs(this.value, rsnh.value)" /> 
  </td>
  
  <td>
  Repetir a senha: 
  </br>
  <input type="password" id="rsnh"  placeholder="Repetir a senha" onkeyup="verifs(snh.value, this.value)"/> 
  </td>
  </tr>
  </br>

  <!-- Linha com a resposta da senha -->
  <tr>
  <td>
  <div id="res" style="font:14px arial; marg in:0px 0px; visibility:hidden;"></div>
  </tr>
  </td>
  
  
  </table>
  </br>
  </br>
  
  <!-- Condição para o técnico junior não poder fazer o que não pode -->
  <button id='btnalt' class='btn' onclick='incuser(logid.value, user.value, eml.value, log.value, tpct.value, snh.value, rsnh.value, tpct1.value)'>Enviar</button>
   </div>


        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
