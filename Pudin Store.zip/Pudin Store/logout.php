<?php
	/* Destroi a sessão, junto com todas as variaveis de login. E redirecionamento para a pagina de login */
    session_start();
    session_destroy();
    header('Location: index.php');
?>