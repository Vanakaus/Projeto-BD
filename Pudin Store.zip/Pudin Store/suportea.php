<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>
  
  
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
      <table id='tabela'>
        <div id="tit"><p>Suporte</p></div>
    <tr> <th colspan='20'>Chamados</th> </tr>
    <!-- Colunas -->
    <tr>
    <th class='stss'>Status</th>
    <th class='cli'>Cliente</th>
    <th class='abert'>Abertura</th>
    <th class='mot'>Motivo</th>
    <th class='tec'>Tecnico</th>
    <th class='ini'>Início do atendimento</th>
    <th class='paus'>Pausas</th>
    <th class='obsc'>Observação do Cliente</th>
    <th class='acs'>Ações</th>
    </tr>
    
    <!-- Linhas -->
    <tr class='dif'>
    <td class='sts1' title='Ultima alteração: 10/010/2018'>ESP</td>

    <td title='Chamado id'>nome cliente</td> 
    <td>10/10/2018</td> 
    <td>problema</td>

    <td class='sts1'>funcionario</td>

    <td>10/10/2018</td>        
    
    <td title='descrição'>pausas</td> 
    <td title='Observação Completa'>observação</td>    
    
    <td><button >...</button></td>
    </tr>
    <tr>
    <td class='sts2' title='Ultima alteração: 10/010/2018'>ESP</td>

    
    <td title='Chamado id'>nome cliente</td> 
    <td>10/10/2018</td> 
    <td>problema</td>

    <td class='sts2'>funcionario</td>

    <td>10/10/2018</td>        
    
    <td title='descrição'>pausas</td> 
    <td title='Observação Completa'>observação</td>    
    
    <td><button >...</button></td>
    </tr>
    <tr class='dif'>
    <td class='sts3' title='Ultima alteração: 10/010/2018'>ESP</td>

    
    <td title='Chamado id'>nome cliente</td> 
    <td>10/10/2018</td> 
    <td>problema</td>

    <td class='sts3'>funcionario</td>

    <td>10/10/2018</td>        
    
    <td title='descrição'>pausas</td> 
    <td title='Observação Completa'>observação</td>    
    
    <td><button >...</button></td>
    </tr>
    <tr>
    <td class='sts4' title='Ultima alteração: 10/010/2018'>ESP</td>

    
    <td title='Chamado id'>nome cliente</td> 
    <td>10/10/2018</td> 
    <td>problema</td>

    <td class='sts4'>funcionario</td>

    <td>10/10/2018</td>        
    
    <td title='descrição'>pausas</td> 
    <td title='Observação Completa'>observação</td>    
    
    <td><button >...</button></td>
    </tr>
    <tr class='dif'>
    <td class='sts5' title='Ultima alteração: 10/010/2018'>ESP</td>

    
    <td title='Chamado id'>nome cliente</td> 
    <td>10/10/2018</td> 
    <td>problema</td>

    <td class='sts5'>funcionario</td>

    <td>10/10/2018</td>        
    
    <td title='descrição'>pausas</td> 
    <td title='Observação Completa'>observação</td>    
    
    <td><button >...</button></td>
    </tr>
    

  </table>
          

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
