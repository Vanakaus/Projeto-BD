<?php

 require_once "config.php";


	$btn = $_REQUEST["btn"];
	
	
	switch($btn) {
		case "alt":

		$senhaa = md5($_REQUEST["senhaa"]);
		$senhan = md5($_REQUEST["senhan"]);

		$select = mysqli_query($conectbd, "select senha from login where senha='".$senhaa."' and user='".$_SESSION['usuario']."';");
		
		$rows = mysqli_fetch_array($select);
		
		if ($rows['senha'] == $senhaa ) {
			
		$update = mysqli_query($conectbd, "update login set senha='$senhan' where senha='".$senhaa."'");
		echo "1";
			
		} else{
			echo "2";
		}
		
		
			break;
}
	
	
	