  <!DOCTYPE html>
  <html>
  <head>
    <script type="text/javascript">
      function cat(cat){
        var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var x = xmlhttp.responseText; // Resposta do login
                }

        };
        xmlhttp.open("GET", "cat.php?cat=" + cat, true);
        xmlhttp.send();
        location.reload();
      }
    </script>
  </head>
  <body>
  
  </body>
  </html>


<?php
	echo "
  <main role='main'>
      <div id='categorias'>
        <ul>
          <li><a href='prodg.php'>Gerenciar</a></li>
          <li><a href='proda.php'>Adicionar</a></li>
          </ul>
      </div>";

?>