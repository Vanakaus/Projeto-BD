<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  ?>


    <main role="main">
      <div id="categorias">
        <ul>
          <li><a href="chamado.php">Abrir Chamado</a></li>
          <li><a href="chamadoh.php">Historico</a></li>
          <li><a href="configurar.php">Alterar Dados</a></li>
        </ul>
      </div>
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Chamado</p></div>

          <div id="contaba">
            <h1>Abrir Chamado</h1>
            </br>

              </br>

            

          Motivo:
          </br></br>
          <font class='obss'>Para pular linha, insira " <b>;</b> " e presione enter.</font></br>
          <textarea id = 'motivo' rows='8' cols='70'></textarea>
          </select>
        </br></br></br>
        <!-- Observação -->
        <div id='observacao'>
          <p> Observação: </p>
          <font class='obss'>Para pular linha, insira " <b>;</b> " e presione enter.</font></br>
          <textarea id = 'obs' rows='10' cols='70'></textarea>
        </div>
        </br></br>
        <input type='button' id='btn' class='btn' value='Enviar' onclick='incalt(codigo.value, cliente.value, tcnc.value, prob.value, obs.value)' />
        </div>
      </br>



        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
