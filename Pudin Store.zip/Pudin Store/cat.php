<?php
	/* Início de sessão */
	
	require_once "config.php";
	
	$_SESSION["cat"] = $_REQUEST["cat"];
	echo $_SESSION["cat"];
?>