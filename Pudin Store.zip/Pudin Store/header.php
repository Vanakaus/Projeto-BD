  <!DOCTYPE html>
  <html>
  <head>
    <script type="text/javascript">
      function cat(cat){
        var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var x = xmlhttp.responseText; // Resposta do login
                }

        };
        xmlhttp.open("GET", "cat.php?cat=" + cat, true);
        xmlhttp.send();
        location.reload();
      }
    </script>
  </head>
  <body>
  
  </body>
  </html>
<?php
    echo " 
    <header>
    	<a href='javascript:cat(0);''><img id='logo' src='Imagens/pudinzinho.png'></a>
    	<input type='busca' name='busca' placeholder=' Buscar'></input>
    	<a href='#busca'><img id='lupa' src='Imagens/lupa.png'></a>";

    	if ($_SESSION["perm"] == "") {
    		echo "<button onclick='window.location.href=`login.php`' id='ent' type='button' name='login'>Entrar/Cadastrar</button>";
    	} else {
    		echo "Bem vindo, {$_SESSION['usuario']}";
    	}


    echo "
    	<a href='#car'><img id='car' src='Imagens/cesta.png'></a>
    	<div class='dropdown'>
    		<a href='#menu'><img id='menu' src='Imagens/pudinzinhoo.png'></a>
    		<div class='dropdown-content'>";
    	


    			if ($_SESSION["perm"] == "") {
    				echo "
    				<a href='login.php'>Suporte</a>
    				<a href='logout.php'>Sair</a>";
    			} elseif ($_SESSION["perm"] == 1) {
    				echo "
    				<a href='suportef.php'>Suporte</a>
                    <a href='prodg.php'>Produtos</a>
                    <a href='logout.php'>Sair</a>";
    			} else {
    				echo "
    				<a href='chamado.php'>Suporte</a>
    				<a href='logout.php'>Sair</a>";
    			}

    echo "   	

    			</div>
    		</div>
    		
    </header>";

?>