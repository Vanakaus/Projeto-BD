  <!DOCTYPE html>
  <html>
  <head>
    <script type="text/javascript">
      function cat(cat){
        var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var x = xmlhttp.responseText; // Resposta do login
                }

        };
        xmlhttp.open("GET", "cat.php?cat=" + cat, true);
        xmlhttp.send();
        location.reload();
      }
    </script>
  </head>
  <body>
  
  </body>
  </html>


<?php
	echo "
    <main role='main'>

      <div id='categorias'>
      	<ul>
      		<li><a href='javascript:cat(1);'>Armazenamentos</a></li>
      		<li><a href='javascript:cat(2);'>Cabos</a></li>
      		<li><a href='javascript:cat(3);'>Peças</a></li>
      		<li><a href='javascript:cat(4);'>Periféricos</a></li>
      	</ul>
      </div>";

?>