<?php
 require_once "config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    
<?php
  require_once "header.php";
  require_once "menu3.php";
  ?>


    
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Suporte</p></div>

          <div id="contaba">
            <h1>Incluir/Alterar Chamado</h1>
            <input type="radio" name="ia" id="inc" value="incluir" onclick="incluir()" checked>Incluir</input>

            <input type='radio' name='ia' id='alt' value='alterar' onclick='alterar()'>Alterar</input>
            </br>
            </br>
            <div id="chmd" hidden>
              Chamado:
              <input type="number" name="codigo" id="codigo"  placeholder="Código" />
              </br>
              </br>
            </div>

            <div id='cli'>Cliente: <select id ='cliente'  class='appearance-select'>
              <option selected hidden value='0'>Qual o cliente</option>
              <option value='cliente'>nome cliente</option>
            </select></br></br>
          </div>
          <div id='tec'>Técnico:
           <select id ='tcnc' class='appearance-select'>
            <option selected hidden value=''>Técnico</option>
            <option value='tecnico'>funcionario</option>
            </select></br></br>
          </div>

          Motivo:
          </br></br>
          <font class='obss'>Para pular linha, insira " <b>;</b> " e presione enter.</font></br>
          <textarea id = 'motivo' rows='8' cols='70'></textarea>
          </select>
        </br></br></br>
        <!-- Observação -->
        <div id='observacao'>
          <p> Observação: </p>
          <font class='obss'>Para pular linha, insira " <b>;</b> " e presione enter.</font></br>
          <textarea id = 'obs' rows='10' cols='70'></textarea>
        </div>
        </br></br>
        <input type='button' id='btn' class='btn' value='Enviar' onclick='incalt(codigo.value, cliente.value, tcnc.value, prob.value, obs.value)' />
        </div>
      </br>



        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
