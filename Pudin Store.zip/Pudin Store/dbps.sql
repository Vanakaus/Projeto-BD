-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 15-Nov-2018 às 01:59
-- Versão do servidor: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbps`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `email` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `user` varchar(32) CHARACTER SET utf8mb4 NOT NULL,
  `empresa` varchar(60) DEFAULT NULL,
  `telefone1` varchar(11) DEFAULT NULL,
  `telefone2` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`email`, `user`, `empresa`, `telefone1`, `telefone2`) VALUES
('vinicius_vnk@hotmail.com', 'Vnks', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(32) NOT NULL,
  `func` tinyint(1) DEFAULT '0',
  `nome` varchar(80) NOT NULL,
  `senha` text NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`user`, `func`, `nome`, `senha`) VALUES
('Func', 1, 'Oswaldo', 'ow123'),
('Vnks', 0, 'Vinicius simoes', 'e0b73a1699aeee785d156388f584cf74');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

DROP TABLE IF EXISTS `produto`;
CREATE TABLE IF NOT EXISTS `produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(70) DEFAULT NULL,
  `valor` decimal(6,2) DEFAULT NULL,
  `descricao` varchar(800) DEFAULT NULL,
  `desconto` decimal(10,0) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `nome`, `valor`, `descricao`, `desconto`, `categoria`) VALUES
(8, 'Memória Kingston HyperX FURY 4GB', '305.76', 'Entre no jogo com HyperX FURY. Até novatos começam com altas velocidades, já que o FURY reconhece automaticamente sua plataforma host e faz o overclock automaticamente para a maior frequência publicada, proporcionando grande poder para seu próximo jogo. O modelo de dissipador de calor assimétrico do FURY permite que você se destaque nos jogos.', '0', 'Armazenamento'),
(7, 'HD WD SATA 3,5´ Blue PC 1TB', '282.24', 'As unidades de disco rígido WD Blue fornecem um desempenho e confiabilidade sólidos, enquanto que disponibilizam todo o espaço que você precisa para gravar quantidades enormes de fotos, vídeos e arquivos. Essas unidades foram projetadas para serem usadas como unidades principais em PCs de mesa, dispositivos externos e para algumas aplicações industriais.', '0', 'Armazenamento'),
(5, 'HD WD Blue SATA 2.5´ p/ Notebook 1TB', '249.90', 'Construído para os altos padrões de qualidade e confiabilidade da WD, os discos rígidos móveis WD Blue oferecem os recursos que são ideais para suas necessidades diárias de computação móvel.', '0', 'Armazenamento'),
(6, 'HD WD Externo Portátil Elements 1TB', '294.00', 'A WD Elements SE é uma unidade de disco rígido portátil de capacidade máxima, que torna fácil armazenar e transportar todos os seus arquivos importantes.', '0', 'Armazenamento'),
(9, 'Memória Kingston HyperX FURY 8GB', '414.90', 'A memória HyperX FURY está disponível nas capacidades de 4GB e 8GB com frequências que variam entre 1333MHz, 1600MHz e 1866MHz. Todas as memórias HyperX FURY possuem o PCB preto e um dissipador de calor assimétrico, este podendo ser Azul, Preto, Vermelho ou, pela primeira vez, branco. Perfeita para quem procura uma memória de desempenho com um preço acessível, a HyperX FURY é Plug and Play, basta conecta-la que o reconhecimento de sua plataforma host e o overclock é feito automaticamente. Agora cabe a você optar pela HyperX FURY e fazer este upgrade de performance e estilo.', '0', 'Armazenamento'),
(10, 'Pen Drive Kingston DataTraveler USB 3.0 32GB', '39.90', 'A unidade Flash USB DataTraveler 100 G3 (DT100G3) da Kingston é compatível com as especificações para USB 3.0 de última geração para beneficiar-se da tecnologia presente nos novos notebooks, desktops e dispositivos digitais. Com o DT100G3, o armazenamento e transferência de documentos, apresentações, músicas, vídeos e outros arquivos são mais rápidas e fáceis do que nunca.', '0', 'Armazenamento'),
(11, 'SSD Crucial 2.5´ 240GB', '230.47', 'Melhore o desempenho: Carregue arquivos rapidamente. Melhore a capacidade de resposta geral do sistema para todos as suas necessidades de computação. Ferramentas para fácil instalação: Nossas instruções simples, software de clonagem e vídeos de como fazer a instalação simples! Milhões de pessoas atualizaram com um SSD Crucial.', '0', 'Armazenamento'),
(12, 'SSD Kingston 2.5´ 960GB', '999.88', 'SSD confiável e durável para melhor desempenho do computador e respostas ultrarrápidas em multitarefas.', '0', 'Armazenamento'),
(13, 'SSD Sandisk PLUS 2.5 120GB', '145.90', 'A SanDisk, pioneira em tecnologias de armazenamento de estado sólido e a marca de confiança dos profissionais da área, oferece maior velocidade e desempenho com o SanDisk SSD Plus.', '0', 'Armazenamento'),
(14, 'SSD Warrior 2.5´ 240GB', '230.47', 'Melhora o desempenho de seu computador ficando até 10x mais rápido do que um disco rígido comum.', '0', 'Armazenamento'),
(15, 'Cabo de Força MD9 1.5M', '8.90', 'Norma Inmetro: NBR14136 - Cabo de Força MD9 1.5M', '0', 'Cabos'),
(16, 'Cabo de Rede MD9 2,5m', '10.90', 'Cabo de Rede MD9 2,5m CAT6 Azul 7562', '0', 'Cabos'),
(17, 'Cabo EMPIRE Mini DisplayPort', '26.90', 'O Adaptador Mini DisplayPort para HDMI conecta seu dispositivo Apple (MacBook/MacBook Pro ou MacBook Air com uma entrada mini DisplayPort) em projetores, monitores e quaisquer outros dispositivos de alta definição que utilizem entrada HDMI.', '0', 'Cabos'),
(18, 'Cabo HDMI PIX 2m', '11.90', 'Esse cabo dispõe de compatibilidade com gama ampliada de cor, um dos recursos mais recentes para a melhoria da qualidade da imagem', '0', 'Cabos'),
(19, 'Cabo Sata 180°', '4.00', 'Cabo Sata 180°/180° s/ Logo', '0', 'Cabos'),
(20, 'Fortrek Cabo de Dados Sata', '5.90', 'A linha de Cabos Fortrek foi desenvolvida pensando em praticidade e qualidade. Contendo diversos modelos de cabos para atender as mais variadas necessidades, os cabos Fortrek são produzidos com materiais de qualidade, garantindo uma conexão perfeita para equipamentos de Informática e Eletrônicos.', '0', 'Cabos'),
(21, 'Organizador de Cabos MD9 3/4', '11.90', 'Organizador de Cabos MD9 3/4 Preto 1,5M 3331', '0', 'Cabos'),
(22, 'Cooler FAN C3 Tech F7-100 BK Storm 12cm C3T', '14.00', 'Se voce estiver procurando um cooler fan poderoso para melhorar a refrigeração do seu PC, mas não abre mão de um sistema silencioso, o Cooler Storm F7 e ideal para você. Com uma estrutura projetada para suprimir ruídos o F7 e super silencioso e muito versátil, podendo ser montado na parte traseira, superior ou nas laterais, minimizando o calor e proporcionando mais eficiência na circulação de ar dentro do gabinete.', '0', 'Pecas'),
(23, 'Cooler FAN Corsair 120mm Air Series', '43.90', 'As Corsair Air Series LED são ventoinhas de alto fluxo de ar, que combinam eficiência, baixo ruído, alto fluxo de ar e iluminação LED.', '0', 'Pecas'),
(24, 'Fonte Bluecase 250W', '48.90', 'A Bluecase BLU 250 ATX é uma fonte de alimentação com grande relação de custo-benefício. Esta fonte atende à máquinas de configuração básica que necessitam de pouca potência.', '0', 'Pecas'),
(25, 'Fonte Corsair 500W VS500', '267.89', 'A VS500 da Corsair é uma ótima opção se você está montando um sistema doméstico ou comercial com demandas de baixa potência, mas ainda procura a compatibilidade e confiabilidade pelas quais a Corsair é conhecida.', '0', 'Pecas'),
(26, 'Placa de Vídeo VGA EVGA NVIDIA GeForce GTX 1050 TI', '941.06', 'Placa de Vídeo VGA EVGA NVIDIA GeForce GTX 1050 TI Gaming 4GB GDDR5', '0', 'Pecas'),
(27, 'Placa de Vídeo VGA MSI AMD Radeon RX 550', '649.90', 'Placa de Vídeo VGA MSI AMD Radeon RX 550 AERO 4GB ITX OC', '0', 'Pecas'),
(28, 'Placa-Mãe ASRock p/ Intel LGA 1151 mATX H310M-G/M.2', '446.94', 'Placa-Mãe ASRock p/ Intel LGA 1151 mATX H310M-G/M.2 DDR4', '0', 'Pecas'),
(29, 'Placa-Mãe ASUS p/ AMD AM3+ mATX M5A78L-M', '369.90', 'Placa-Mãe ASUS p/ AMD AM3+ mATX M5A78L-M PLUS/USB3, 4x DDR3 HDMI/DVI/VGA, USB 3.0 Frontal, Áudio Gamer', '0', 'Pecas'),
(30, 'Processador AMD FX 8300 Octa Core', '349.90', 'Processador AMD FX 8300 Octa Core, Black Edition, Cache 16MB, 3.3GHz (4.2GHz Max Turbo) AM3+', '0', 'Pecas'),
(31, 'Processador Intel Core i5-7400 Kaby Lake', '749.90', 'Processador Intel Core i5-7400 Kaby Lake 7a Geração, Cache 6MB, 3.0Ghz (3.5GHz Max Turbo), LGA 1151 Intel HD Graphics BX80677I57400', '0', 'Pecas'),
(32, 'Headset Gamer HyperX Cloud Stinger', '210.42', 'O HyperX Cloud Stinger HX-HSCS-BK/LA é o headset ideal para jogadores que procuram leveza e conforto, qualidade de som superior e maior praticidade. Com apenas 275 gramas, ele é confortável no seu pescoço e seus fones de ouvido giram em um ângulo de 90 graus para um melhor encaixe.', '0', 'Perifericos'),
(33, 'Mouse C3 Tech USB Preto', '14.99', 'O MS-30 e um mouse de fácil configuração que oferece ótima navegabilidade e precisão ao alcance de todos com um custo muito acessível para um mouse óptico. Compatível com Computador PC ou Mac com porta USB.', '0', 'Perifericos'),
(34, 'Mouse Gamer Corsair 6000DPI RGB 6 Botões Preto Harpoon', '129.99', 'O mouse HARPOON RGB foi projetado para o melhor desempenho, apresentando um sensor óptico de 6000 DPI com rastreamento avançado para um controle preciso e um design leve e ergonômico para suportar os mais velozes dos movimentos.', '0', 'Perifericos'),
(35, 'Mouse Gamer HyperX Pulsefire FPS 3200dpi', '211.90', 'Gamers hardcore e profissionais sabem que um mouse preciso e confiável pode ser a diferença entre a vitória e a derrota. O Pulsefire FPS HyperX ™ fornece precisão para você poder ficar por cima no seu jogo. Seja o mestre nos headshots ou uma fera no campo de batalha. O Pulsefire FPS tem DPI configurado e pode ser alterado ao simples toque de um botão.', '0', 'Perifericos'),
(36, 'Mouse Gamer Logitech G402 Hyperion Fury', '117.53', 'Logitech G402 Hyperion Fury é o mouse para jogos mais rápido do mundo, com a tecnologia do sensor Fusion Motor, capaz de rastrear de maneira confiável a 400 IPS. Oito botões programáveis e quatro configurações de DPI que pode ser deslocados e dar a precisão que você precisa para dominar o campo de batalha. Materiais leves e os pés de baixa fricção oferecem a sensação mais confortável possível para que as sessões de jogos durem o quanto precisar. Logitech G402 Hyperion Fury oferece um novo nível de velocidade e precisão.', '0', 'Perifericos'),
(37, 'Redragon Garuda', '46.94', 'Redragon Garuda são headset gamers equipados com 2 conectores P2 de 3,5 mm e um comprimento de cabo de 2m. O fone de ouvido é compatível com qualquer dispositivo que tenha uma porta de 3,5 mm para conectividade. Um novo design que se encaixa perfeitamente com as orelhas dos usuários. Fone de ouvido coberto com couro para o máximo conforto de uso. Há também um microfone sensível que permite que você aprecie o bate-papo de voz sem qualquer distração Os controles para ajustar o volume, ou silenciar o microfone na ponta dos seus dedos e oferece um nível de excelência de benefícios ao usar esses aparelhos Indicadores LED no próprio fone de ouvido indicam o status de operação atual do aparelho.', '0', 'Perifericos'),
(38, 'Teclado Fortrek Standard Padrão', '19.90', 'A Linha de Mouses e Teclados Fortrek foi desenvolvida para oferecer aos usuários produtos com recursos essenciais para uma utilização prática e eficiente.', '0', 'Perifericos'),
(39, 'Teclado Gamer C3 Tech Multimidia Preto', '30.90', 'Se você procura um teclado com alta durabilidade, design diferenciado, funções multimidia e layout gamer, o KG-10BK é o teclado perfeito para você, contando com 107 teclas(16 Multimídia) o KG-10BK é o teclado perfeito pra quem está dando os primeiros passos como jogador de alto desempenho.', '0', 'Perifericos'),
(40, 'Teclado Gamer HyperX Alloy FPS PRO Mecânico', '449.90', 'O HyperX Alloy FPS Pro destina-se ao jogador de FPS que deseja um teclado confiável e sem teclado numérico (TKL) para maximizar o espaço. Este teclado de 87 teclas oferece tudo o que um jogador pro­fissional precisa, mas sem o teclado numérico. O Alloy FPS Pro apresenta as teclas com switch CHERRY MX Red e sua estrutura sólida em aço assegura que você terá uma plataforma sólida durante seus jogos. Seu modelo ultra mínimo e o cabo removível tornam o teclado superportátil, mas ainda recheado de recursos; Modo Jogo, funções 100% Anti-Ghosting, N-Key rollover, iluminação vermelha e efeitos dinâmicos HyperX para acentuar o estilo do seu computador.', '0', 'Perifericos'),
(41, 'Teclado Gamer HyperX Mars RGB Mecânico US', '329.90', 'O teclado MARS apresenta retroiluminação que você pode personalizar através do software Genesis, que é fácil de usar. Além disso, suas teclas garantem 50 milhões de toques e sem perda de qualidade. Por fim, você pode contar com um conector USB banhado a ouro e um cabo trançado de 1,8m.', '0', 'Perifericos'),
(42, 'Teclado Gamer Semi-mecânico NOX Krom', '119.90', 'Teclado gaming com estrutura em metal, layout PT-BR, 7 cores de iluminação e função anti-ghosting. Equipado com interruptores semi-mecânicos que combinam o toque suave do teclado de membrana com a sensação táctil e rápida da tecla mecânica.', '0', 'Perifericos'),
(43, 'Teclado Microsoft + Mouse Basic Óptico 600 Black', '120.90', 'Qualidade acessível em um conjunto desktop composto por um teclado compacto e um mouse óptico. O Microsoft Wired Desktop 600 garante uma ótima solução para suas necessidades. O teclado oferece acesso direto aos recursos de mídia mais utilizados do Windows. O design compacto e durável do teclado adapta-se facilmente à maioria das bandejas para teclado e libera mais espaço na sua área de trabalho. E a tecnologia óptica do confortável mouse lhe garante uma ótima precisão.', '0', 'Perifericos');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
