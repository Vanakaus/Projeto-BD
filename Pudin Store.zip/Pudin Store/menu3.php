<?php
	echo "
  <main role='main'>
      <div id='categorias'>
        <ul>
          <li><a href='suportea.php'>Em Andamento</a></li>
          <li><a href='suportef.php'>Finalizados</a></li>
          <li><a href='suportei.php'>Incluir/Alterar</a></li>
          <li><a id='as' href='suportem.php'>Incluir Funcionário</a></li>
        </ul>
      </div>";

?>