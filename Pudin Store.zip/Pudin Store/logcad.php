<?php
	/* Início de sessão */
	require_once "config.php";
	
	/* Request do usuario e senha */
	$logcad = $_REQUEST["logcad"];
	$usuario = $_REQUEST["user"];
	$senha = $_REQUEST["senha"];
	$senha = md5($senha);
	
	/* coneção com o banco e a tabela. Select na tabela */
	$conectbd = mysqli_connect($_SESSION["host"], $_SESSION["user"], $_SESSION["pswd"], $_SESSION["banco"]);
	$select = mysqli_query($conectbd, "select user from login;");

	$x = 0;

	if ($logcad == "log") {
		$select = mysqli_query($conectbd, "select nome, func from login where user = '$usuario' and senha = '$senha';");
		if (!$select || mysqli_num_rows($select) == 0){
		$x = 1;
	}else{
		
		/* Leitura e reposta do login. E gravação na sessão dos dados do usuario */
		$rows = mysqli_fetch_array($select);
		$_SESSION["usuario"] = $usuario;
		$_SESSION["perm"] = $rows['func'];
		$_SESSION["nome"] = $rows['nome'];
		$x = 0;
	}
	}




/*Cadastro do usuraio*/
	if ($logcad == "cad") {
	$nome = $_REQUEST["nome"];
	$email = $_REQUEST["email"];
		/*Verificação se ja existe o usuario*/
			while ($rows = mysqli_fetch_array($select)){
				if ($rows['user'] == $usuario) {
					$x = 1;
				}
			}

			if ($x == 0) {
				$select = mysqli_query($conectbd, "insert into login (user, nome, senha) values('$usuario', '$nome', '$senha');");
				$select = mysqli_query($conectbd, "insert into cliente (email, user) values('$email', $usuario);");
			}
	}
			echo $x;