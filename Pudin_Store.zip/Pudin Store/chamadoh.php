<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/pudinzinho.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="abas.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index.php"><img id="logo" src="Imagens/pudinzinho.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<button onclick="window.location.href='login.php'" id="ent" type="button" name="login">Entrar/Cadastrar</button>
    	<a href="#car"><img id="car" src="Imagens/cesta.png"></a>
    	<a href="#menu"><img id="menu" src="Imagens/pudinzinhoo.png"></a>
    </header>

    <main role="main">
      <div id="categorias">
        <ul>
          <li><a href="chamado.php">Abrir Chamado</a></li>
          <li><a href="chamadoh.php">Historico</a></li>
          <li><a href="configurar.php">Alterar Dados</a></li>
        </ul>
      </div>
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="cat">
        	<div id="tit"><p>Histórico</p></div>


          <table id="tabela">
            <tr>
              <th class='tipo'>Tipo</th>
              <th class='mot'>Motivo</th>
              <th class='dur'>Duração do atendimento</th>
              <th class='obsc'>Observação do Cliente</th>
              <th class='obsc'>Observação do Técnico</th>
            </tr>
            <tr class='dif'>
              <td title='Chamado id'>Nome Cliente</td>
              <td>Problema</td> 
              <td>10/10/2018</td>
              <td title='Descrição'>Obs do Cliente</td>
              <td title='Descrição'>Obs Do Funcionario</td>
            </tr>
            <tr>
              <td title='Chamado id'>Nome Cliente</td>
              <td>Problema</td> 
              <td>10/10/2018</td>
              <td title='Descrição'>Obs do Cliente</td>
              <td title='Descrição'>Obs Do Funcionario</td>
            </tr>
          </table>
        </br>
        </div>



        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Vinícius Simões Vieira, 2046474.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Pudim Store, Com a qualidade do Pudim supremo!</p>
      </div>
    </footer>

  </body>
</html>
